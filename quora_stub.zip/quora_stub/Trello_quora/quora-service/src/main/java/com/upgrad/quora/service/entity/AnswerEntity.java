package com.upgrad.quora.service.entity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.hibernate.validator.constraints.UniqueElements;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Date;

@Entity
@Table(name = "answer")
@NamedQueries(
        {
                @NamedQuery(name = "answerById", query = "select at from AnswerEntity at where at.id =:id"),
                @NamedQuery(name = "answerByUuid", query = "select at from AnswerEntity at where at.uuid =:uuid"),
                @NamedQuery(name = "answerByQuestionId", query = "select at from AnswerEntity at where at.question_id =:question_id")
        }
)

public class AnswerEntity implements Serializable {

    @Id
    @Column(name = "ID", nullable = false)
    @NotNull
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "UUID")
    @Size(max = 200)
    //@NotNull
    private String uuid;

    @Column(name = "ANS")
    @NotNull
    @Size(max = 255)
    private String ans;

    @Column(name = "DATE")
    @NotNull
    @Temporal(TemporalType.DATE)
    private Date date;

    //@OneToMany
    @Column(name = "USER_ID", nullable = false)
    @NotNull
    private Integer userId;

    //@OneToMany(mappedBy = "user_id")
    @Column(name = "QUESTION_ID", nullable = false)
    @NotNull
    private Integer question_id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getAns() {
        return ans;
    }

    public void setAns(String ans) {
        this.ans = ans;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getQuestion_Id() {
        return question_id;
    }

    public void setQuestion_Id(Integer question_Id) {
        this.question_id = question_id;
    }

    @Override
    public boolean equals(Object obj) {
        return new EqualsBuilder().append(this, obj).isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(this).hashCode();
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }


}