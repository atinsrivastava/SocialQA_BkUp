package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.entity.UserEntity;
import com.upgrad.quora.service.exception.SignUpRestrictedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserBusinessService {
    @Autowired
    private UserDao userDao;

    @Autowired
    private PasswordCryptographyProvider passwordCryptographyProvider;

    @Transactional(propagation = Propagation.REQUIRED)
    public UserEntity signup(UserEntity userEntity) {
        String[] encryptedText = passwordCryptographyProvider.encrypt(userEntity.getPassword());
        userEntity.setSalt(encryptedText[0]);
        userEntity.setPassword(encryptedText[1]);
        return userDao.createUser(userEntity);
    }

    public void verifyUserExistance(UserEntity userEntity) throws SignUpRestrictedException {
        UserEntity userEmail = userDao.getUserByEmail(userEntity.getEmail());
        UserEntity user = userDao.getUserByUserName(userEntity.getUserName());
        if (null != userEmail && userEntity.getEmail().equals(userEmail.getEmail())) {
            throw new SignUpRestrictedException("SGR-002", "This user has already been registered, try with any other emailId");
        } else if (null != user && userEntity.getUserName().equals(user.getUserName())) {
            throw new SignUpRestrictedException("SGR-001", "Try any other Username, this Username has already been taken");
        }

    }

    public void userSignOutValidation(String accessTokenFromRequest){

        UserAuthEntity userAuthToken = userDao.getUserAuthToken(accessTokenFromRequest);
        if(null != userAuthToken){
            //Update logoutAt time
        }
        else
        {
            //Throw Exception
        }

    }
}

