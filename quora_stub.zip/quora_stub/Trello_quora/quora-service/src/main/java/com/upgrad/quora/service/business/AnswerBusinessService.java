package com.upgrad.quora.service.business;

import com.upgrad.quora.service.dao.AnswerDao;
import com.upgrad.quora.service.dao.UserDao;
import com.upgrad.quora.service.entity.AnswerEntity;
import com.upgrad.quora.service.entity.UserAuthEntity;
import com.upgrad.quora.service.exception.AnswerNotFoundException;
import com.upgrad.quora.service.exception.AuthorizationFailedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AnswerBusinessService {

    @Autowired
    private AnswerDao answerDao;
    @Autowired
    private UserDao userDao;

    public void updateAnswer(String uuid, String content ) {
        AnswerEntity ae = answerDao.getAnswerByUuid(uuid);
        ae.setAns(content);
        //qe.setDate(new java.util.Date());
        answerDao.updateAnswer(ae);
    }

    public AnswerEntity validateAnswerEditRequest(final String uuid, final String accessToken) throws AuthorizationFailedException, AnswerNotFoundException {
        UserAuthEntity userAuthEntity = userDao.getUserAuthToken(accessToken);
        AnswerEntity answerEntity = answerDao.getAnswerByUuid(uuid);
        if(userAuthEntity == null){
            throw new AuthorizationFailedException("ATHR-001", "User has not signed in");
        }else{
            if(userAuthEntity.getLogoutAt() != null && userAuthEntity.getLogoutAt().isBefore(userAuthEntity.getExpiresAt()))
            {
                throw new AuthorizationFailedException("ATHR-002", "User is signed out.Sign in first to edit and answer");
            }
            else if (answerEntity == null){
                throw new AnswerNotFoundException("ANS-001", "Entered answer uuid does not exist");
            }
            else if((userAuthEntity.getUser().getId() != (answerEntity.getUserId()))){
                throw new AuthorizationFailedException("ATHR-003", "Only the answer owner can edit the answer");
            }else{
                return answerEntity;
            }
        }
    }

}
